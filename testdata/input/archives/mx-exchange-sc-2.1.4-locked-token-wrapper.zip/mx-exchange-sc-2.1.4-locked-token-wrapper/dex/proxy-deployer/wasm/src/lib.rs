////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

elrond_wasm_node::wasm_endpoints! {
    proxy_deployer
    (
        callFarmEndpoint
        deployFarm
        getAllDeployedFarms
        getDeployerFarmAddresses
    )
}

elrond_wasm_node::wasm_empty_callback! {}
