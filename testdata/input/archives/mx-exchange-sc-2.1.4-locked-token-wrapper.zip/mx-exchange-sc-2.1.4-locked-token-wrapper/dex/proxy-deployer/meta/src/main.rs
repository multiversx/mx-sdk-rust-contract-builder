fn main() {
    elrond_wasm_debug::meta::perform::<proxy_deployer::AbiProvider>();
}
