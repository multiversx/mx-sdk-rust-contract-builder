////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

elrond_wasm_node::wasm_endpoints! {
    pair_mock
    (
        addInitialLiquidity
        updateAndGetTokensForGivenPositionWithSafePrice
    )
}

elrond_wasm_node::wasm_empty_callback! {}
