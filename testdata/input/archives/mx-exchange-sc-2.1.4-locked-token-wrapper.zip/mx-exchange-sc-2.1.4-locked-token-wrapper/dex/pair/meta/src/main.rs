fn main() {
    elrond_wasm_debug::meta::perform::<pair::AbiProvider>();
}
