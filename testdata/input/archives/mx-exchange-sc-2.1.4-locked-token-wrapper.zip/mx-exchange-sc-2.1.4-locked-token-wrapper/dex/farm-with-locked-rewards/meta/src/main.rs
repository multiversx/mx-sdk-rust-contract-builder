fn main() {
    elrond_wasm_debug::meta::perform::<farm_with_locked_rewards::AbiProvider>();
}
