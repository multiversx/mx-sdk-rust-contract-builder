fn main() {
    elrond_wasm_debug::meta::perform::<fees_collector::AbiProvider>();
}
