pub const WRONG_TOKEN_ID: &[u8] = b"Wrong payment token id for fee";
pub const MIN_AMOUNT_NOT_REACHED: &[u8] = b"Minimum amount not reached";
pub const MIN_FEES_REACHED: &[u8] = b"Propose already reached min threshold for fees";
