fn main() {
    elrond_wasm_debug::meta::perform::<governance_v2::AbiProvider>();
}
