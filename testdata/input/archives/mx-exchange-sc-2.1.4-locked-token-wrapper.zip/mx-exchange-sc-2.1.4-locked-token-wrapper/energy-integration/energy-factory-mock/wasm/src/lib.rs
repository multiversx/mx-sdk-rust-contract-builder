////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

elrond_wasm_node::wasm_endpoints! {
    energy_factory_mock
    (
        getEnergyAmountForUser
        getEnergyEntryForUser
        setUserEnergy
    )
}

elrond_wasm_node::wasm_empty_callback! {}
