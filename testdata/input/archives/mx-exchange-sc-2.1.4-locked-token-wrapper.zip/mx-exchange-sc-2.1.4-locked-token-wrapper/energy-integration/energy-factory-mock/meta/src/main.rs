fn main() {
    elrond_wasm_debug::meta::perform::<energy_factory_mock::AbiProvider>();
}
