fn main() {
    elrond_wasm_debug::meta::perform::<energy_update::AbiProvider>();
}
