fn main() {
    elrond_wasm_debug::meta::perform::<simple_lock_whitelist::AbiProvider>();
}
