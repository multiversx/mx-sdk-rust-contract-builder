////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

elrond_wasm_node::wasm_endpoints! {
    lkmex_transfer
    (
        getAllSenders
        getEnergyFactoryAddress
        lockFunds
        setEnergyFactoryAddress
        withdraw
    )
}

elrond_wasm_node::wasm_empty_callback! {}
