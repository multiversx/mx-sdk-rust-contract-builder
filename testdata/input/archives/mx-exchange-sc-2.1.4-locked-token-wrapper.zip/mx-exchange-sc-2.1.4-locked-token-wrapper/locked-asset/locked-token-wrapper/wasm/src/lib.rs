////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

elrond_wasm_node::wasm_endpoints! {
    locked_token_wrapper
    (
        callBack
        getEnergyFactoryAddress
        getLockedTokenId
        getWrappedTokenId
        issueWrappedToken
        setEnergyFactoryAddress
        setTransferRoleWrappedToken
        unsetTransferRoleWrappedToken
        unwrapLockedToken
        wrapLockedToken
    )
}
