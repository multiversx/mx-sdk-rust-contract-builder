fn main() {
    elrond_wasm_debug::meta::perform::<locked_token_wrapper::AbiProvider>();
}
