fn main() {
    elrond_wasm_debug::meta::perform::<farm_staking::AbiProvider>();
}
