////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

elrond_wasm_node::wasm_endpoints! {
    farm_staking_proxy
    (
        callBack
        claimDualYield
        getDualYieldTokenId
        getFarmTokenId
        getLpFarmAddress
        getLpFarmTokenId
        getLpTokenId
        getPairAddress
        getStakingFarmAddress
        getStakingTokenId
        registerDualYieldToken
        stakeFarmTokens
        unstakeFarmTokens
    )
}
